# include "rectBlocks.h"

void readrectblocks(ifstream &infile, vector<rectBlocks> &rectblocks){

while(infile >> Width1 >> Height1 >> Length1){
        rectBlocks block= rectBlocks(Width1,Height1,Length1);
        rectblocks.push_back(block);
    }
 }