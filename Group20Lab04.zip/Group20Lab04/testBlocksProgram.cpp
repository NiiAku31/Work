 # include "rectBlocks.h"


 ifstream infile;
    infile.open("dataBlocks.dat");
    infile >> Width1 >> Height1 >> Length1;

	readrectblocks(infile, Length1);

	vector<rectBlocks> rectblocks;
    vector<sqrBaseRectBlocks> squarebaseblocks;
    vector<cuboidBlocks> cuboidblocks;
    vector<sphericalBlocks> sphericalblocks;
    vector<cylindricalBlocks> cylindricalblocks;


    createblocks(Length1,rectblocks,squarebaseblocks,cuboidblocks,cylindricalblocks);


    sortcylinder(cylindricalblocks);
    displaycylinder(cylindricalblocks)
    Displaysphere(sphericalblocks);
    sortsphere(sphericalblocks);

    infile.close();
    cin.get();
}
