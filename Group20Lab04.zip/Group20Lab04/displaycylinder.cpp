#include "rectBlocks.h"

void displayCylinders(const vector<cylindricalblocks> & cylindricalblocks){cout << endl;

    cout << "The Cylindrical Blocks Computation is as follows:" << endl;
    cout<<"Diameter      "<<"Volume      "<<"Surface Area"<<endl;
    cout<<"----------------------------------------------"<<endl;

    for(int a = 0; a<cylindricalblocks.size();a++){
        cout << cylindricalblocks[a].Diameter << " " << surfaceOfcylinder(cylindricalblocks[a].Diameter,cylindricalblocks[a].Length) << " "<< cylindricalblocks[a].Length;
    }