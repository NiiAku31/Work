#include "rectBlocks.h"

void displaySphere(const vector<sphericalblocks> & sphericalblocks){
	cout << endl << "The Spherical Blocks Computation is as follows:" << endl;
    cout<<"Diameter      "<<"Volume      "<<"Surface Area"<<endl;
    cout<<"---------------------------------------------- "<<endl;

    for(int i = 0; i<sphericalblocks.size();i++){
        cout << sphericalblocks[i].Diameter<< " "<<surfaceOfsphere(sphericalblocks[i].Diameter) << "  " << volumeOfsphere(sphericalblocks[i].Diameter) << endl;

}