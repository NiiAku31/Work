#include "rectBlocks.h"

sort(cylindricalblocks.begin(), cylindricalblocks.end(), [](cylindricalBlocks THREE, cylindricalBlocks FOUR){
        return THREE.Diameter < FOUR.Diameter;
    });