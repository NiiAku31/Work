
#include "rectBlocks.h"

sort(sphericalblocks.begin(), sphericalblocks.end(), [](sphericalBlocks ONE, sphericalBlocks TWO){
        return ONE.Diameter < TWO.Diameter;
    });