#include "rectBlocks.h"

double surfaceOfsphere(int Diameter){
    return PI*Diameter*Diameter;
}
