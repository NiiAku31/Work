#include <iostream>
#include <fstream>
#include <cstdlib>
#include <vector>
#include <algorithm> 

#define PI 3.14


using namespace std;





class rectBlocks{
    public:
    int Width;
    int Height;
    int Length;
    int Diameter;

    rectBlocks(){
        Width = 0;
        Height = 0;
        Length = 0;
    }

    rectBlocks(int aWidth, int aHeight, int aLength){
        Width = aWidth;
        Height = aHeight;
        Length = aLength;
    }
};

class sqrBaseRectBlocks :public rectBlocks{
    public:
    sqrBaseRectBlocks(){
        Width = 0;
        Height = 0;
        Length = 0;
        }

    sqrBaseRectBlocks(int aWidth, int aLength){
        Width = aWidth;
        Height = aWidth;
        Length = aLength;
    }
};

class cuboidBlocks : public sqrBaseRectBlocks{
    public:
    cuboidBlocks(){
        Width = 0;
        Height = 0;
        Length = 0;
        }

    cuboidBlocks(int aWidth){
        Width = aWidth;
        Height = aWidth;
        Length = aWidth;
    }
};

class cylindricalBlocks : public sqrBaseRectBlocks{
    public:
    int Diameter;
    cylindricalBlocks(int aDiameter, int aLength){
        Diameter = aDiameter;
        Length = aLength;
    }
};


class sphericalBlocks : public cuboidBlocks{
    public:
    int Diameter;
    sphericalBlocks(int aDiameter){
        Diameter = aDiameter;
    }
};

