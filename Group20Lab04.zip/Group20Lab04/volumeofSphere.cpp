#include "rectBlocks.h"

double volumeOfsphere(int Diameter){
    return (PI*Diameter*Diameter*Diameter)/6;
}