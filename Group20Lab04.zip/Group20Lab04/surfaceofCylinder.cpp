#include "rectBlocks.h"

double  surfaceOfcylinder(int Diameter, int Length){
    return PI*Diameter*Length + (PI*Diameter*Diameter)/2;
}
